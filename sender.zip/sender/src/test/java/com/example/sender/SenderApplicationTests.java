package com.example.sender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
